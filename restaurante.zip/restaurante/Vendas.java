import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Vendas {

    public static void exibirRelatorioVendas() {
        JFrame vendasFrame = new JFrame("Relatório de Vendas");
        vendasFrame.setSize(400, 300);
        vendasFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        vendasFrame.setLocationRelativeTo(null); // Centralizar na tela

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel label = new JLabel("Digite o nome do prato:");
        panel.add(label);

        JTextField pratoField = new JTextField();
        pratoField.setMaximumSize(new Dimension(300, 30));
        panel.add(pratoField);

        JButton buscarButton = new JButton("Buscar");
        panel.add(buscarButton);

        JLabel resultadoLabel = new JLabel();
        resultadoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        resultadoLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        panel.add(resultadoLabel);

        buscarButton.addActionListener(e -> {
            String prato = pratoField.getText().trim();
            if (!prato.isEmpty()) {
                int quantidade = contarVendas(prato);
                resultadoLabel.setText("Quantidade vendida: " + quantidade);
            } else {
                JOptionPane.showMessageDialog(vendasFrame, "Digite o nome do prato.");
            }
        });

        JButton voltarButton = new JButton("Voltar");
        panel.add(voltarButton);

        voltarButton.addActionListener(e -> {
            vendasFrame.dispose(); // Fechar a tela de Vendas
            InterfaceFuncRest.criarInterfaceFuncRestGUI(); // Voltar para a tela principal
        });

        vendasFrame.add(panel);
        vendasFrame.setVisible(true);
    }

    private static int contarVendas(String prato) {
        int quantidade = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader("PedidosConfirmados.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(prato)) {
                    quantidade++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return quantidade;
    }
}
