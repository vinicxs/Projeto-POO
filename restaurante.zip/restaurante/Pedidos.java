import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Pedidos {

    public static void criarPedidosGUI() {
        JFrame pedidosFrame = new JFrame("Pedidos");
        pedidosFrame.setSize(400, 300);
        pedidosFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel tituloLabel = new JLabel("Selecione os pratos:");
        panel.add(tituloLabel);

        List<String> pratos = carregarPratos();
        List<JCheckBox> checkBoxes = new ArrayList<>();

        for (String prato : pratos) {
            JCheckBox checkBox = new JCheckBox(prato);
            checkBoxes.add(checkBox);
            panel.add(checkBox);
        }

        JButton confirmarButton = new JButton("Confirmar Pedido");
        JButton voltarButton = new JButton("Voltar");

        panel.add(Box.createVerticalStrut(20));
        panel.add(voltarButton);
        panel.add(confirmarButton);

        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pedidosFrame.dispose();
                InterfaceFuncRest.criarInterfaceFuncRestGUI();
            }
        });

        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<String> pratosSelecionados = new ArrayList<>();
                for (JCheckBox checkBox : checkBoxes) {
                    if (checkBox.isSelected()) {
                        pratosSelecionados.add(checkBox.getText());
                    }
                }
                if (!pratosSelecionados.isEmpty()) {
                    pedidosFrame.dispose();
                    Entrega.criarEntregaGUI(pratosSelecionados);
                } else {
                    JOptionPane.showMessageDialog(pedidosFrame, "Por favor, selecione ao menos um prato.");
                }
            }
        });

        pedidosFrame.add(panel);
        pedidosFrame.setVisible(true);
    }

    private static List<String> carregarPratos() {
        List<String> pratos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("PratosRest.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                pratos.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pratos;
    }
}
