import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfaceFuncRest {

    private static JFrame frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> criarInterfaceFuncRestGUI());
    }

    public static void criarInterfaceFuncRestGUI() {
        frame = new JFrame("Funcionalidades do Restaurante");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 3, 10, 10));

        JButton estoqueButton = new JButton("Estoque");
        JButton avaliacaoButton = new JButton("Avaliação");
        JButton entregaButton = new JButton("Entrega");
        JButton pedidosButton = new JButton("Pedidos");
        JButton vendasButton = new JButton("Vendas");
        JButton fecharButton = new JButton("Fechar");

        panel.add(estoqueButton);
        panel.add(avaliacaoButton);
        panel.add(entregaButton);
        panel.add(pedidosButton);
        panel.add(vendasButton);
        panel.add(fecharButton);

        estoqueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new Estoque(frame).exibirInterface();
            }
        });

        avaliacaoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Ação do botão de Avaliação");
            }
        });

        entregaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Entrega.exibirPedidosConfirmados();
            }
        });

        pedidosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                Pedidos.criarPedidosGUI();
            }
        });

        vendasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                Vendas.exibirRelatorioVendas();
            }
        });

        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}
