import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.List;

public class Entrega {

    public static void criarEntregaGUI(List<String> pratosSelecionados) {
        JFrame entregaFrame = new JFrame("Entrega");
        entregaFrame.setSize(400, 300);
        entregaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel tituloLabel = new JLabel("Selecione o Tipo de Retirada:");
        panel.add(tituloLabel);

        JRadioButton retiradaLocalRadio = new JRadioButton("Retirada no Local");
        JRadioButton entregaCasaRadio = new JRadioButton("Entrega em Casa");

        ButtonGroup grupo = new ButtonGroup();
        grupo.add(retiradaLocalRadio);
        grupo.add(entregaCasaRadio);

        panel.add(retiradaLocalRadio);
        panel.add(entregaCasaRadio);

        JTextField enderecoField = new JTextField();
        enderecoField.setMaximumSize(new Dimension(300, 30));
        enderecoField.setEnabled(false); // Desabilitar até a opção de entrega em casa ser selecionada
        panel.add(enderecoField);

        entregaCasaRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enderecoField.setEnabled(true);
            }
        });

        retiradaLocalRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enderecoField.setEnabled(false);
            }
        });

        JButton confirmarButton = new JButton("Confirmar");
        JButton voltarButton = new JButton("Voltar");

        panel.add(Box.createVerticalStrut(20));
        panel.add(voltarButton);
        panel.add(confirmarButton);

        voltarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entregaFrame.dispose();
                Pedidos.criarPedidosGUI();
            }
        });

        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (retiradaLocalRadio.isSelected()) {
                    salvarPedido(pratosSelecionados, null);
                    JOptionPane.showMessageDialog(entregaFrame, "Pedido confirmado para retirada no local.");
                } else if (entregaCasaRadio.isSelected() && !enderecoField.getText().isEmpty()) {
                    salvarPedido(pratosSelecionados, enderecoField.getText());
                    JOptionPane.showMessageDialog(entregaFrame, "Pedido confirmado para entrega em casa no endereço: " + enderecoField.getText());
                } else {
                    JOptionPane.showMessageDialog(entregaFrame, "Por favor, selecione um tipo de retirada e preencha o endereço, se necessário.");
                }
            }
        });

        entregaFrame.add(panel);
        entregaFrame.setVisible(true);
    }

    private static void salvarPedido(List<String> pratos, String endereco) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("PedidosConfirmados.txt", true))) {
            for (String prato : pratos) {
                writer.write(prato);
                writer.newLine();
            }
            if (endereco != null) {
                writer.write("Endereço de entrega: " + endereco);
                writer.newLine();
            }
            writer.write("---");
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void exibirPedidosConfirmados() {
        StringBuilder conteudo = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("PedidosConfirmados.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                conteudo.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (conteudo.length() == 0) {
            conteudo.append("Não há pedidos no momento.");
        }

        JOptionPane.showMessageDialog(null, conteudo.toString(), "Pedidos Confirmados", JOptionPane.INFORMATION_MESSAGE);
    }
}
